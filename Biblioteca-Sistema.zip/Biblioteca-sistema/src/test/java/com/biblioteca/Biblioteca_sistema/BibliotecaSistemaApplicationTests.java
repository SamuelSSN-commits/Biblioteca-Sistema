package com.biblioteca.Biblioteca_sistema;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BibliotecaSistemaApplicationTests {

	@Test
	void contextLoads() {
	}

}
