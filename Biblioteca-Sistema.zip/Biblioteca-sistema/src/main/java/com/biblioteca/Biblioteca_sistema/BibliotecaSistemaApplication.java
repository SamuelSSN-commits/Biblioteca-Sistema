package com.biblioteca.Biblioteca_sistema;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BibliotecaSistemaApplication {

	public static void main(String[] args) {
		SpringApplication.run(BibliotecaSistemaApplication.class, args);
	}

}
